package com.company;

import java.util.List;
import java.util.Map;

public interface Observer {
    void update(String matches);

}
